# require_optional
Work around the problem that we do not have a optionalPeerDependencies concept in node.js making it a hassle to optionally include native modules
