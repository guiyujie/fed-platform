# History
----

## 1.5.0 / 2016-07-27

-

## 1.4.5 / 2016-03-02

- if exists getPopupContainer it will be passed to Trigger component

## 1.4.0 / 2015-10-26

- update for react 0.14

## 1.2.0 / 2015-06-07

- remove closeOnSelect, use visible prop to control

## 0.8.0 / 2015-06-07

Already available
