
1.6.0 / 2015-01-11
==================

  * feat: exports thenify
  * support node 0.8+

1.5.0 / 2015-01-09
==================

  * feat: support backward compatible with callback
