declare const DialogWrap: any;
export default DialogWrap;
