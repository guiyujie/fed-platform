# History
---

## 1.7.0 / 2016-05-20
- add `inputValue` api.

### break change
- search item and select it, will save search text and result.

## 1.6.0-beta / 2016-05-03
- add `treeDataSimpleMode` api.

## 1.5.2 / 2016-04-02
- `skipHandleInitValue` is deprecated, use `treeCheckStrictly` instead.

## 1.4.0 / 2016-03-14
- change `showAllChecked`/`showParentChecked` to `showCheckedStrategy`.

## 1.3.0 / 2016-03-14
- add `showAllChecked`/`showParentChecked` API.

## 1.2.0 / 2016-02-29
- change onChange's third parameter, from flat array to tree's hierarchical structure.

## 1.1.x / 2016-02-26
- stable version
