# History
----

## 1.2.0 / 2017-05-15

- support stopPropagation for onPress and onLongPress

## 1.0.0 / 2016-11-29

- inspired by react-native
