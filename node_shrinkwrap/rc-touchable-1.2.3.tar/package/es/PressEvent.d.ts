declare function PressEvent(nativeEvent: any): void;
export declare function shouldFirePress(e: any): boolean;
export default PressEvent;
