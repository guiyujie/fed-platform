# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

<a name="0.5.9"></a>
## [0.5.9](https://github.com/webpack/url-loader/compare/v0.5.8...v0.5.9) (2017-06-12)


### Bug Fixes

* `String` not being `base64` encoded ([#67](https://github.com/webpack/url-loader/issues/67)) ([e9496b9](https://github.com/webpack/url-loader/commit/e9496b9))
* don't default to `0` (`options.limit`) ([#74](https://github.com/webpack/url-loader/issues/74)) ([020c2a8](https://github.com/webpack/url-loader/commit/020c2a8))



# Change Log

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.
