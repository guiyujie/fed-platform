import chai from 'chai';
import chaiDeepEqual from 'chai-shallow-deep-equal';

chai.use(chaiDeepEqual);
