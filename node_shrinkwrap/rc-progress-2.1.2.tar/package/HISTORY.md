# History

---

## 2.1.0
- Add `gapDegree` `gapPosition` props.

## 2.0.0

- refactor code
- Add `prefixCls` `className` `style` props.
- Add `strokeLinecap` for shape of end in progress bar.
