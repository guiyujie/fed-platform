# History
----

## 1.2.0 / 2016-03-22

- support offsetTop/Left/Bottom/Right
