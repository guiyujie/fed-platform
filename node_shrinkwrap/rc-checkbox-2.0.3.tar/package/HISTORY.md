# 1.5.0

- Refactor dom structure for better focus style.
