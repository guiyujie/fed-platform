'use strict';

var basename = require('path').basename;
var debug = require('debug')('css-modules:preset');
var dirname = require('path').dirname;
var hook = require('./lib/index');
var seekout = require('seekout');

var preset = seekout('cmrh.conf.js', dirname(module.parent.filename));

if (preset) {
  debug('\u2192 ' + basename(preset));
  hook(require(preset));
} else {
  debug('\u2192 defaults');
  hook({});
}
