## 1.4.0

- Added `getContainer` property.
