export const POSITIONS = ['left', 'top', 'right', 'bottom'];
