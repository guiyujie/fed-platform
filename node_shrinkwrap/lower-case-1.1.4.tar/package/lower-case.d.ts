declare function lowerCase (value: string, locale?: string): string;

export = lowerCase;
