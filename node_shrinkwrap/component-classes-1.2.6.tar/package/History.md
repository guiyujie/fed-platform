
1.2.6 / 2016-04-01
==================

  * fix: properly fix `component-indexof` require (#29, @ockham)

1.2.5 / 2016-02-28
==================

  * package: don't use browser alias for component-indexof dependency (#27, @ockham)

1.2.4 / 2015-03-17
==================

  * fix: classes(el).array() when el is an svg element.

1.2.3 / 2014-11-19
==================

  * index: Improve HTMLElement duck typing
  * Readme: Display new test command
  * Makefile: Install and use local component binaries
  * package: Add component dev deps
  * test: Use component/assert

1.2.2 / 2014-10-27
==================

  * bump version to 1.2.2
  * pin component-indexof to 0.0.3 in package.json
  * package: add "license" field

1.2.1 / 2014-02-10
==================

  * package: use "component-indexof"

1.2.0 / 2014-01-16
==================

  * add `.toggle()` force parameter
  * change npm package name to `component-classes`

1.1.4 / 2013-11-14
==================

  * package: allow any "indexof-component" version
  * add repository field to `package.json`

1.1.3 / 2013-08-02
==================

 * add browser field to map indexof -> indexof-component
 * throw an Error if no DOM element is given

1.1.2 / 2013-06-10
==================

 * fix leading / trailing whitespace leading to empty string in .array() retval

1.1.0 / 2013-01-30
==================

  * add .remove(regexp) support

0.0.2 / 2012-08-01
==================

  * add support for <body> tags. Closes #1 [domenic]

0.0.1 / 2010-01-03
==================

  * Initial release
