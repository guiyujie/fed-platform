# History
----

## 2.3.4 / 2017-04-17

- fix `createClass` and `PropTypes` warning.

## 2.3.0 / 2016-05-26

- add forceAlign method
