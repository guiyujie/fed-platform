## 2.1.0

- Fix typo `charactor` to `character`.

## 2.0.0

- Add `character`.
- Add `className`.
- Add `onHoverChange(value)`.
