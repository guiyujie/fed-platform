export default class ConfigStore {
    private _store;
    constructor();
    set(key: any, value: any): void;
    get(key: any): any;
}
