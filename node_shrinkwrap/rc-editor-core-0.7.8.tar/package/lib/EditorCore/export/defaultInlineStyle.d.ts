declare var _default: {
    BOLD: {
        'font-weight': string;
    };
};
export default _default;
