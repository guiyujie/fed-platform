import EditorCore from './EditorCore';
declare const EditorCorePublic: {
    EditorCore: typeof EditorCore;
    GetText: (editorState: any, options?: {
        encode: boolean;
    }) => string;
    GetHTML: (editorState: any) => any;
    toEditorState: (text: string) => any;
};
export default EditorCorePublic;
