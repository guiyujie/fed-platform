=== HEAD

=== 2.0.0 (August 18, 2015)

* Only touch DOM when the `matches` function is run.
* Support IE 10+. Remove IE 9 orphan node fix.

=== 1.0.1 (August 20, 2014)

* Fallback uses `for` loop instead of reverse `while`.

=== 1.0.0 (August 16, 2014)

* Initial release.
