// small polyfill for babel
module.exports = require('./lib').default;
