require('LiveScript');
// eslint-disable-next-line import/no-unresolved
module.exports = require('./build/Gruntfile');
