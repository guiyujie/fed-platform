require('../../modules/es7.math.isubh');
module.exports = require('../../modules/_core').Math.isubh;
