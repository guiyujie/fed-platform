require('../../modules/es6.array.reduce');
module.exports = require('../../modules/_core').Array.reduce;
