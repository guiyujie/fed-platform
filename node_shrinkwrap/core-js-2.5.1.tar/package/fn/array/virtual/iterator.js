require('../../../modules/es6.array.iterator');
module.exports = require('../../../modules/_iterators').Array;
