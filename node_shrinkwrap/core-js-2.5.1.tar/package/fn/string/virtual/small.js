require('../../../modules/es6.string.small');
module.exports = require('../../../modules/_entry-virtual')('String').small;
