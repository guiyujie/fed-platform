# History
----

## 1.5.0

- support useCssTransform

## 1.4.0

- only flip if it's visible


## 1.1.0

- support targetOffset
- offset/targetOffset support percentage value