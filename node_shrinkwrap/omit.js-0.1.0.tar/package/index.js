'use strict';

var assign = require('object-assign');

module.exports = function omit(obj, fields) {
  var copy = assign({}, obj);
  for (var i = 0; i < fields.length; i++) {
    var key = fields[i];
    delete copy[key];
  }
  return copy;
};
