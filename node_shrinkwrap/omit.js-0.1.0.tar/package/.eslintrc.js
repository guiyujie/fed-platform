'use strict';

module.exports = {
  extends: 'eslint-config-egg',
  rules: {
    'no-var': 0,
  }
};
