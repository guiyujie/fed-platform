
0.2.1 / 2016-10-31
==================

  * loose debug version (#21, @roderickhsiao)
  * component: update "repo" field

0.2.0 / 2015-03-18
==================

 * add `bower.json`
 * add travis/zuul/saucelabs testing
 * add support for custom callback `name`
 * pin `debug` dep

0.1.0 / 2014-12-30
==================

  * Make sure `script.parentNode` exists before removing the script element (#12, @azer)
  * Return function to cancel in-progress jsonp request (#11, @feross)
  * add documentation for `prefix` option (#10, @feross)

0.0.4 / 2014-03-11
==================

  * simplify the variable name "id" creation logic
  * Readme: add Installation notes
  * fix jshint warnings
  * add repository field to `package.json`
  * fallback to `document.head` if there is not any script tags in the dom
  * remove script safely

0.0.3 / 2013-02-03
==================

  * use `index.js`
  * go back to integer ids
  * honor `param` option

0.0.2 / 2013-02-03
==================

  * make IE<=8 happy

0.0.1 / 2012-07-03
==================

  * Initial release.
